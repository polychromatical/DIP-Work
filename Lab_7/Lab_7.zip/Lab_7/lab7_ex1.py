# -*- coding: utf-8 -*-
"""
Created on Wed Oct 14 13:56:08 2020

@author: User
"""

import numpy as np
import cv2
from matplotlib import pyplot as pt
from filter import lpfilter

f = cv2.imread("cameraman.bmp",0)

F = np.fft.fft2(f)
Fs = np.fft.fftshift(F)

[nrow,ncol] = f.shape
H = lpfilter(nrow,ncol,"ideal",75)

G = H * Fs

Gs = np.fft.ifftshift(G)
g = np.fft.ifft2(Gs)

g = g.real
g[g < 0] = 0
g[g > 255] = 255

pt.figure()
pt.subplot(1,2,1)
pt.imshow(f,cmap="gray")
pt.title("Before")

pt.figure()
pt.subplot(1,2,2)
pt.imshow(g,cmap="gray")
pt.title("After")