# -*- coding: utf-8 -*-
"""
Created on Tue Aug 25 12:24:58 2020

@author: User
"""

import numpy

big_arr100 = numpy.zeros((200,200),dtype=numpy.int32)

big_arr100[0:200,0:200] = 100